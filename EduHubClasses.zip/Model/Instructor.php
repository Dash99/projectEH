<?php

class Instructor implements Manipulate{
    
    private $instructorID;
    private $title;
    private $qualification;
    
    public function getInstructorID() {
        return $this->instructorID;
    }

    public function getTitle() {
        return $this->title;
    }

    public function getQualification() {
        return $this->qualification;
    }

    public function setInstructorID($instructorID) {
        $this->instructorID = $instructorID;
    }

    public function setTitle($title) {
        $this->title = $title;
    }

    public function setQualification($qualification) {
        $this->qualification = $qualification;
    }
    
    public function addNew(){
        
    }


    public function updateById($id) {
        
    }

    public function deleteById($id) {
        
    }

    public function getById($id) {
        
    }

}
