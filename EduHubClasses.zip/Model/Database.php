<?php

class Database {
    
    const SERVER = "localhost";
    const USERNAME = "root";
    const PASSWORD = "";
    const DATABASE = "eduHubDB";
    private $connection;
    
    public function __construct() {
        $this->setConnection(mysql_connect(Database::SERVER, Database::USERNAME, Database::PASSWORD));
        mysql_select_db(Database::DATABASE);
    }
    
    private function setConnection($connection) {
        $this->connection = $connection;
    }

        
    public function getConnection(){
        return $this->connection;
    }
    
    public function close(){
        mysql_close();
    }

    
    
}
