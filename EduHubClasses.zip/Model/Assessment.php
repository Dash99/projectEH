<?php

class Assessment extends Activity implements Manipulate {
    

    private $duration;
    private $examiner;
    private $totalMark;

    public function getDuration() {
        return $this->duration;
    }

    public function getExaminer() {
        return $this->examiner;
    }

    public function getTotalMark() {
        return $this->totalMark;
    }

    public function setDuration($duration) {
        $this->duration = $duration;
    }

    public function setExaminer($examiner) {
        $this->examiner = $examiner;
    }

    public function setTotalMark($totalMark) {
        $this->totalMark = $totalMark;
    }

    

}
