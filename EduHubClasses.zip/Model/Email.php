<?php

/**
 * Description of Email
 *
 * @author Tsosane MJ 
 */
class Email {

    private $studentNumber, $instructorID, $subject, $message, $dateTime;

    function __construct() {
        setStudentNumber(0);
        setinstructorID("");
        setSubject("");
        setMessage("");
        setDateTime(date(DATE_RFC2822));
    }

    function setStudentNumber($studentNumber) {
        $this->studentNumber = $studentNumber;
    }

    function setInstructorID() {
        $this->instructorID = $instructorID;
    }

    function setSubject($subject) {
        $this->subject = $subject;
    }

    function setMessage($message) {
        $this->message = $message;
    }

    function setDateTime($dateTime) {
        $this->dateTime = $dateTime;
    }

}
