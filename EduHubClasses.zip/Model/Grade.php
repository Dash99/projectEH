<?php

/**
 * Description of Grade
 *
 * @author Tsosane MJ 
 */
class Grade implements Manipulate {

    private $activityID, $StudentID;

    public function Grade() {
        setActivityID("");
        setStudentID(0);
    }

    public function __construct($activityID, $StudentID) {
        $this->activityID = $activityID;
        $this->StudentID = $StudentID;
    }

    public function setActivityID($activityID) {
        $this->activityID = $activityID;
    }

    public function setStudentID($StudentID) {
        $this->StudentID = $StudentID;
    }

    public function getActivityID() {
        return $this->activityID;
    }

    public function getStudentID() {
        return $this->StudentID;
    }

    public function deleteById($id) {
        
    }

    public function getById($id) {
        
    }

    public function updateById($id) {
        
    }

}
