<?php
class Assignment extends Activity {
    
    private $endDate;
    
    public function getEndDate() {
        return $this->endDate;
    }

    public function setEndDate($endDate) {
        $this->endDate = $endDate;
    }

    public function addActivity(){
        
    }

    public function deleteById($id) {
        
    }

    public function getById($id) {
        
    }

    public function updateById($id) {
        
    }

}
