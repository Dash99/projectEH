<?php
class Student extends Person implements Manipulate {
   
    private $studentNo;
    
    public function getStudentNo() {
        return $this->studentNo;
    }

    public function setStudentNo($studentNo) {
        $this->studentNo = $studentNo;
    }
    
    public function addNew() {
        
    }

    public function updateById($id) {
        
    }

}
