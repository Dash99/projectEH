<?php

/**
 * Description of Course_Subject
 *
 * @author Tsosane MJ
 */
class CourseSubject implements Manipulate {

    private $courseCode, $subjectCode;

    public function CourseSubject() {
        setCourseCode("");
        setSubjectCode("");
    }

    public function __construct($courseCode, $subjectCode) {
        $this->courseCode = $courseCode;
        $this->subjectCode = $subjectCode;
    }

    public function setCourseCode($courseCode) {
        $this->courseCode = $courseCode;
    }

    public function setSubjectCode($subjectCode) {
        $this->subjectCode = $subjectCode;
    }

    public function getCourseCode() {
        return $this->courseCode;
    }

    public function getSubjectCode() {
        return $this->subjectCode;
    }

    public function deleteById($id) {
        
    }

    public function getById($id) {
        
    }

    public function updateById($id) {
        
    }

}
