<?php

class Address implements Manipulate{
    
    private $addressID;
    private $street;
    private $suburb;
    private $city;
    private  $zip;
    
    public function __construct() {
        $this->addressID = "";
        $this->street = "";
        $this->suburb = "";
        $this->city = "";
        $this->zip = "";
    }
    
    public function Address($addressID, $street, $suburb, $city, $zip) {
        $this->addressID = $addressID;
        $this->street = $street;
        $this->suburb = $suburb;
        $this->city = $city;
        $this->zip = $zip;
    }
    
    public function getAddressID() {
        return $this->addressID;
    }

    public function getStreet() {
        return $this->street;
    }

    public function getSuburb() {
        return $this->suburb;
    }

    public function getCity() {
        return $this->city;
    }

    public function getZip() {
        return $this->zip;
    }

    public function setAddressID($addressID) {
        $this->addressID = $addressID;
    }

    public function setStreet($street) {
        $this->street = $street;
    }

    public function setSuburb($suburb) {
        $this->suburb = $suburb;
    }

    public function setCity($city) {
        $this->city = $city;
    }

    public function setZip($zip) {
        $this->zip = $zip;
    }

    public function deleteById($id) {
        
    }

    public function getById($id) {
        
    }

    public function updateById($id) {
        
    }

}
