<?php

abstract class Person implements Manipulate{

    protected $personID;
    protected $firstName;
    protected $initials;
    protected $lastName;
    protected $gender;
    protected $address;
    protected $email;
    protected $password;

    public function __construct() {
        $this->personID = "";
        $this->firstName = "";
        $this->initials = "";
        $this->lastName = "";
        $this->gender = "";
        $this->address = null;
        $this->email = "";
        $this->password = "";
    }

    public function Person($personID, $firstName, $initials, $lastName, $gender, $address, $email, $password) {
        $this->personID = $personID;
        $this->firstName = $firstName;
        $this->initials = $initials;
        $this->lastName = $lastName;
        $this->gender = $gender;
        $this->address = $address;
        $this->email = $email;
        $this->password = $password;
    }
    
    public function getPersonID() {
        return $this->personID;
    }

    public function getFirstName() {
        return $this->firstName;
    }

    public function getInitials() {
        return $this->initials;
    }

    public function getLastName() {
        return $this->lastName;
    }

    public function getGender() {
        return $this->gender;
    }

    public function getAddress() {
        return $this->address;
    }

    public function getEmail() {
        return $this->email;
    }

    public function getPassword() {
        return $this->password;
    }

    public function setPersonID($personID) {
        $this->personID = $personID;
    }

    public function setFirstName($firstName) {
        $this->firstName = $firstName;
    }

    public function setInitials($initials) {
        $this->initials = $initials;
    }

    public function setLastName($lastName) {
        $this->lastName = $lastName;
    }

    public function setGender($gender) {
        $this->gender = $gender;
    }

    public function setAddress($address) {
        $this->address = $address;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function setPassword($password) {
        $this->password = $password;
    }

    
}
