<?php

/**
 * Description of Subject
 *
 * @author Tsosane MJ 
 */
class Subject implements Manipulate {

    private $subCode, $name, $description, $module;

    public function Subject() {
        setCode("");
        setName("");
        setDescription("");
        setModule("");
    }

    public function __construct($subCode, $name, $description, $module) {
        setCode($subCode);
        setName($name);
        setDescription($module);
        setDescription($description);
    }

    public function getSubCode() {
        return $this->subCode;
    }

    public function getName() {
        return $this->name;
    }

    public function getDescription() {
        return $this->description;
    }

    public function getModule() {
        return $this->module;
    }

    public function setSubCode($subCode) {
        $this->subCode = $subCode;
    }

    public function setName($name) {
        $this->name = $name;
    }

    function setDescription($description) {
        $this->description = $description;
    }

    public function setModule($module) {
        $this->module = $module;
    }

    public function deleteById($id) {
        
    }

    public function getById($id) {
        
    }

    public function updateById($id) {
        
    }

}
