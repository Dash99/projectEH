<?php

interface Manipulate {
    
    
    public function deleteById($id);
    
    public function updateById($id);
    
    public function getById($id);
    
}
