<?php

abstract class Activity implements Manipulate {

    protected $name;
    protected $description;
    protected $date;
    protected $startTime;
    protected $endTime;

    public function __construct() {
        $this->name = "";
        $this->description = "";
        $this->date = "";
        $this->startTime = "";
        $this->endTime = "";
    }

    public function Activity($name, $description, $date, $startTime, $endTime) {
        $this->name = $name;
        $this->description = $description;
        $this->date = $date;
        $this->startTime = $startTime;
        $this->endTime = $endTime;
    }
    
    public function getName() {
        return $this->name;
    }

    public function getDescription() {
        return $this->description;
    }

    public function getDate() {
        return $this->date;
    }

    public function getStartTime() {
        return $this->startTime;
    }

    public function getEndTime() {
        return $this->endTime;
    }

    public function setName($name) {
        $this->name = $name;
    }

    public function setDescription($description) {
        $this->description = $description;
    }

    public function setDate($date) {
        $this->date = $date;
    }

    public function setStartTime($startTime) {
        $this->startTime = $startTime;
    }

    public function setEndTime($endTime) {
        $this->endTime = $endTime;
    }


    // CRUD Methods
    
}
