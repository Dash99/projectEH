<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of newPHPClass
 *
 * @author Tsosane Johannes
 */
class Course implements Manipulate {

    private $courseCode, $name, $description;

    public function setCourseCode($courseCode) {
        $this->courseCode = $courseCode;
    }

    public function setName($name) {
        $this->name = $name;
    }

    public function setDescription($description) {
        $this->description = $description;
    }

    public function __construct($courseCode, $name, $description) {
        setName($name);
        setDesription($description);
        setCourseCode($courseCode);
    }

    public function getCourseCode() {
        return $this->courseCode;
    }

    public function getName() {
        return $this->name;
    }

    public function getDescription() {
        return $this->description;
    }

    public function addCourse() {
        
    }

    public function deleteById($id) {
        
    }

    public function getById($id) {
        
    }

    public function updateById($id) {
        
    }

}
